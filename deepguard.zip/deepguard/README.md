# DeepGuard — Système Intelligent de Détection de Deepfakes

Mémoire M2 IA & Big Data — GNANGNON Dorel Médéliac — PIGIER BÉNIN 2025-2026

## Installation locale

```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

Ouvrir : http://localhost:8000

## Structure
- `main.py` — API FastAPI
- `model.py` — Architecture HybridDeepfakeDetector
- `predict.py` — Logique prédiction image/vidéo
- `static/index.html` — Interface web

## Déploiement Render
1. Push sur GitHub
2. Connecter le repo sur render.com
3. Uploader best_model.pth dans les fichiers du service
